# PTMHS Reunion 2026 — Free Hosting Starter

এই ZIP-এ বর্তমান ওয়েবসাইটের frontend (`index.html`) এবং Supabase database-এর প্রাথমিক SQL schema আছে।

## গুরুত্বপূর্ণ অবস্থা
এটি এখনো LIVE/production registration system নয়।
- বর্তমান HTML demo-তে ফর্মের তথ্য সার্ভারে সংরক্ষিত হয় না।
- bKash Transaction ID স্বয়ংক্রিয়ভাবে যাচাই হয় না।
- অফিসিয়াল PDF slip, QR check-in এবং Admin Dashboard এখনো backend-এর সঙ্গে যুক্ত নয়।
- bKash Personal নম্বরকে payment gateway হিসেবে দেখানো যাবে না; এটি শুধু Send Money নির্দেশনা।

## বিনামূল্যে প্রকাশের প্রস্তাব
1. GitHub-এ একটি private বা public repository তৈরি করুন।
2. এই ZIP extract করে সব ফাইল repository-তে upload করুন।
3. Vercel-এ account খুলে GitHub repository import করুন।
4. Framework preset `Other`, build command ফাঁকা, output directory `.` রেখে Deploy দিন।
5. Vercel একটি free `*.vercel.app` address দেবে। সেটিই প্রথম free website URL হবে।

## Database
1. Supabase-এ free project তৈরি করুন।
2. SQL Editor-এ `supabase/schema.sql` ফাইলের SQL চালান।
3. `service_role` key কখনো HTML/JavaScript বা public repository-তে রাখবেন না।
4. Registration submission-এর জন্য server-side Edge Function/API তৈরি করতে হবে; public browser থেকে সরাসরি participant table read/update খোলা যাবে না।

## ৫টি Admin Role
- Main Admin
- Treasurer
- Registration Manager 1
- Registration Manager 2
- Check-in Manager

প্রত্যেকের আলাদা login, role-based access এবং নিরাপদ password reset প্রয়োজন। Admin email/নাম না পাওয়া পর্যন্ত account তৈরি করা যাবে না।

## Go-live checklist
- [ ] GitHub repository তৈরি
- [ ] Vercel deploy
- [ ] Supabase project ও schema
- [ ] Server-side registration API + rate limiting
- [ ] Admin authentication + 5 roles
- [ ] Manual payment verification workflow
- [ ] Verified-only PDF slip + QR token
- [ ] QR check-in + duplicate scan prevention
- [ ] Privacy notice, data retention, backup
- [ ] Test registrations and admin permissions

Hosting account-এ user নিজে sign in করে repository connect/Deploy অনুমোদন করবেন। Password, OTP, bKash PIN বা secret key chat-এ পাঠাবেন না।
