-- PTMHS Reunion 2026: initial Supabase schema
-- Run in Supabase SQL Editor. Enable RLS. Do not expose service_role key in browser code.

create extension if not exists pgcrypto;

create table if not exists public.registrations (
  id uuid primary key default gen_random_uuid(),
  registration_code text unique,
  full_name text not null,
  batch text not null,
  phone text not null,
  email text,
  profession text,
  emergency_phone text,
  address text,
  bkash_trx_id text not null unique,
  payment_status text not null default 'pending'
    check (payment_status in ('pending','verified','rejected')),
  checked_in boolean not null default false,
  qr_token uuid not null default gen_random_uuid() unique,
  created_at timestamptz not null default now(),
  verified_at timestamptz,
  verified_by uuid
);

-- Public visitors may not read participant records.
alter table public.registrations enable row level security;

-- Intentionally no public SELECT/UPDATE policy.
-- Production inserts should go through a server-side Edge Function/API
-- that validates input, rate-limits requests, and assigns registration_code.
-- Admin access should use authenticated users + role-based policies.
